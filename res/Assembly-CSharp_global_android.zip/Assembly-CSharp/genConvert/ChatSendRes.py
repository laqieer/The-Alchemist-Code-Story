def ChatSendRes(json):
    this={}#ChatSendResjson)
    #if(json==null)
    #return
    if 'is_success' in json:
        this['is_success'] = json['is_success']
return this
