def TowerRoundRewardParam(json):
    this={}#TowerRoundRewardParamjson)
    #if(json==null)
    #thrownewInvalidJSONException()
    if 'iname' in json:
        this['iname'] = json['iname']
    #this.mRoundList=newList<byte>()
    #if(json.rewards==null)
    #return
    #this.mTowerRewardItems=newList<TowerRewardItem>()
    #for(intindex=0index<json.rewards.Length++index)
        #TowerRewardItemtowerRewardItem=newTowerRewardItem()
        #towerRewardItem.Deserialize((JSON_TowerRewardItem)json.rewards)
        #this.mTowerRewardItems.Add(towerRewardItem)
        #this.mRoundList.Add(json.rewards.round_num)
return this
