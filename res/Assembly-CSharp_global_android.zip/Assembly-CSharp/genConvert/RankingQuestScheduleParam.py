def RankingQuestScheduleParam(json):
    this={}#RankingQuestScheduleParamjson)
    if 'id' in json:
        this['id'] = json['id']
    #this.beginAt=DateTime.MinValue
    #this.endAt=DateTime.MaxValue
    #if(!string.IsNullOrEmpty(json.begin_at))
    #DateTime.TryParse(json.begin_at,outthis.beginAt)
    #if(!string.IsNullOrEmpty(json.end_at))
    #DateTime.TryParse(json.end_at,outthis.endAt)
    #this.reward_begin_at=DateTime.MinValue
    #this.reward_end_at=DateTime.MaxValue
    #if(!string.IsNullOrEmpty(json.reward_begin_at))
    #DateTime.TryParse(json.reward_begin_at,outthis.reward_begin_at)
    #if(!string.IsNullOrEmpty(json.reward_end_at))
    #DateTime.TryParse(json.reward_end_at,outthis.reward_end_at)
    #this.visible_begin_at=DateTime.MinValue
    #this.visible_end_at=DateTime.MaxValue
    #if(!string.IsNullOrEmpty(json.visible_begin_at))
    #DateTime.TryParse(json.visible_begin_at,outthis.visible_begin_at)
    #if(!string.IsNullOrEmpty(json.visible_end_at))
    #DateTime.TryParse(json.visible_end_at,outthis.visible_end_at)
    #returntrue
return this
