def RaidDamageRatioRewardParam(json):
    this={}#RaidDamageRatioRewardParamjson)
    #if(json==null)
    #returnfalse
    if 'id' in json:
        this['mId'] = json['id']
    #this.mRewards=newList<RaidDamageRatioRewardWeightParam>()
    #if(json.rewards!=null)
        #for(intindex=0index<json.rewards.Length++index)
            #RaidDamageRatioRewardWeightParamrewardWeightParam=newRaidDamageRatioRewardWeightParam()
            #if(rewardWeightParam.Deserialize(json.rewards))
            #this.mRewards.Add(rewardWeightParam)
    #returntrue
return this
