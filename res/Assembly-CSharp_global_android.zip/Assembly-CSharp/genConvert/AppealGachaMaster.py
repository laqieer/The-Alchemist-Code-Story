def AppealGachaMaster(json):
    this={}#AppealGachaMasterjson)
    #if(json==null)
    #returnfalse
    if 'fields' in json:
        this['appeal_id'] = json['fields'].appeal_id
    if 'fields' in json:
        this['start_at'] = TimeManager.FromDateTime)
    if 'fields' in json:
        this['end_at'] = TimeManager.FromDateTime)
    if 'fields' in json:
        this['is_new'] = json['fields'].flag_new!=0
    #returntrue
return this
