def VersusRankRewardParam(json):
    this={}#VersusRankRewardParamjson)
    #if(json==null)
    #returnfalse
    if 'reward_id' in json:
        this['mRewardId'] = json['reward_id']
    #this.mRewardList=newList<VersusRankReward>()
    #for(intindex=0index<json.rewards.Length++index)
        #VersusRankRewardversusRankReward=newVersusRankReward()
        #if(versusRankReward.Deserialize(json.rewards))
        #this.mRewardList.Add(versusRankReward)
    #returntrue
return this
