def RecipeParam(json):
    this={}#RecipeParamjson)
    #if(json==null)
    #returnfalse
    if 'iname' in json:
        this['iname'] = json['iname']
    if 'cost' in json:
        this['cost'] = json['cost']
    #intlength=0
    #stringstrArray=newstring[5]{json.mat1,json.mat2,json.mat3,json.mat4,json.mat5}
    #for(intindex=0index<strArray.Length&&!string.IsNullOrEmpty(strArray)++index)
    #++length
    #if(length>0)
        #intnumArray=newint[5]{json.num1,json.num2,json.num3,json.num4,json.num5}
        #this.items=newRecipeItem[length]
        #for(intindex=0index<length++index)
            #this.items=newRecipeItem()
            #this.items.iname=strArray
            #this.items.num=numArray
    #returntrue
return this
