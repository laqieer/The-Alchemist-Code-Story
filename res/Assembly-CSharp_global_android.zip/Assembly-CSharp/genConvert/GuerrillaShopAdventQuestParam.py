def GuerrillaShopAdventQuestParam(json):
    this={}#GuerrillaShopAdventQuestParamjson)
    if 'id' in json:
        this['id'] = json['id']
    if 'qid' in json:
        this['qid'] = json['qid']
    #returntrue
return this
