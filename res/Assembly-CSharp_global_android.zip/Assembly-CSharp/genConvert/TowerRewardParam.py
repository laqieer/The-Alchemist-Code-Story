def TowerRewardParam(json):
    this={}#TowerRewardParamjson)
    #if(json==null)
    #thrownewInvalidJSONException()
    if 'iname' in json:
        this['iname'] = json['iname']
    #if(json.rewards==null)
    #return
    #this.mTowerRewardItems=newList<TowerRewardItem>()
    #for(intindex=0index<json.rewards.Length++index)
        #TowerRewardItemtowerRewardItem=newTowerRewardItem()
        #towerRewardItem.Deserialize(json.rewards)
        #this.mTowerRewardItems.Add(towerRewardItem)
return this
