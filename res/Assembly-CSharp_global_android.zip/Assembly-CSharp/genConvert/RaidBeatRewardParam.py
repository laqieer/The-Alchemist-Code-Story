def RaidBeatRewardParam(json):
    this={}#RaidBeatRewardParamjson)
    #if(json==null)
    #returnfalse
    if 'id' in json:
        this['mId'] = json['id']
    #this.mRewards=newList<RaidBeatRewardDataParam>()
    #if(json.rewards!=null)
        #for(intindex=0index<json.rewards.Length++index)
            #RaidBeatRewardDataParambeatRewardDataParam=newRaidBeatRewardDataParam()
            #if(beatRewardDataParam.Deserialize(json.rewards))
            #this.mRewards.Add(beatRewardDataParam)
    #returntrue
return this
