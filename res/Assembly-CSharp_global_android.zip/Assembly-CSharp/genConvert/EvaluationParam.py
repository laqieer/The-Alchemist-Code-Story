def EvaluationParam(json):
    this={}#EvaluationParamjson)
    #if(json==null)
    #returnfalse
    if 'iname' in json:
        this['iname'] = json['iname']
    if 'val' in json:
        this['value'] = json['val']
    #this.status.Clear()
    this['']
    this['status']
    if 'hp' in json:
        this['status']['hp'] = json['hp']
    this['status']
    if 'mp' in json:
        this['status']['mp'] = json['mp']
    this['status']
    if 'atk' in json:
        this['status']['atk'] = json['atk']
    this['status']
    if 'def' in json:
        this['status']['def'] = json['def']
    this['status']
    if 'mag' in json:
        this['status']['mag'] = json['mag']
    this['status']
    if 'mnd' in json:
        this['status']['mnd'] = json['mnd']
    this['status']
    if 'dex' in json:
        this['status']['dex'] = json['dex']
    this['status']
    if 'spd' in json:
        this['status']['spd'] = json['spd']
    this['status']
    if 'cri' in json:
        this['status']['cri'] = json['cri']
    this['status']
    if 'luk' in json:
        this['status']['luk'] = json['luk']
    #returntrue
return this
