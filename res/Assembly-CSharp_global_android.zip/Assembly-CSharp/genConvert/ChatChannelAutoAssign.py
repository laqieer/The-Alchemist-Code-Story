def ChatChannelAutoAssign(json):
    this={}#ChatChannelAutoAssignjson)
    #if(json==null)
    #return
    if 'channel' in json:
        this['channel'] = json['channel']
return this
