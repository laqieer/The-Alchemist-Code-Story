﻿// Decompiled with JetBrains decompiler
// Type: AlchemistGooglePlay
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E2D362ED-2CBE-44F0-8985-22128799036A
// Assembly location: D:\User\Desktop\Assembly-CSharp.dll

public static class AlchemistGooglePlay
{
  public const string achievement_blue_flame_guard = "CgkIgsmSkdUXEAIQBw";
  public const string achievement_battler = "CgkIgsmSkdUXEAIQAg";
  public const string achievement_determination = "CgkIgsmSkdUXEAIQCQ";
  public const string achievement_raking_it_in = "CgkIgsmSkdUXEAIQCA";
  public const string achievement_elite_evolver = "CgkIgsmSkdUXEAIQBg";
  public const string achievement_the_adventure_begins = "CgkIgsmSkdUXEAIQAQ";
  public const string achievement_mercenary = "CgkIgsmSkdUXEAIQAw";
  public const string achievement_veteran = "CgkIgsmSkdUXEAIQBA";
  public const string achievement_seasoned_warrior = "CgkIgsmSkdUXEAIQCg";
  public const string achievement_battle_hardened = "CgkIgsmSkdUXEAIQBQ";
}
