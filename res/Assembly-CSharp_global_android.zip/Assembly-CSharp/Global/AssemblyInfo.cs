﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Assembly-CSharp-Editor")]
[assembly: Extension]
[assembly: AssemblyVersion("0.0.0.0")]
