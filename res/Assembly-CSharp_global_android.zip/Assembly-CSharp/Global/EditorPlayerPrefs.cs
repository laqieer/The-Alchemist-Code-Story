﻿// Decompiled with JetBrains decompiler
// Type: EditorPlayerPrefs
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E2D362ED-2CBE-44F0-8985-22128799036A
// Assembly location: D:\User\Desktop\Assembly-CSharp.dll

public static class EditorPlayerPrefs
{
  public static void DeleteAll()
  {
  }

  public static int CountKeys()
  {
    return 0;
  }

  public static void DeleteKey(string key)
  {
  }

  public static void Flush()
  {
  }

  public static bool HasKey(string key)
  {
    return false;
  }

  public static void SetInt(string key, int value)
  {
  }

  public static int GetInt(string key)
  {
    return 0;
  }

  public static void SetString(string key, string value)
  {
  }

  public static string GetString(string key)
  {
    return (string) null;
  }
}
